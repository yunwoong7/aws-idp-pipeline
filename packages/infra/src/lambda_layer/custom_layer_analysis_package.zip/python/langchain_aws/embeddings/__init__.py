from langchain_aws.embeddings.bedrock import BedrockEmbeddings

__all__ = ["BedrockEmbeddings"]
