mupdf_location='https://mupdf.com/downloads/archive/mupdf-1.26.1-source.tar.gz'
